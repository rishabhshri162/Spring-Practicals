package com.rays.test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Job {
	
	private String developer;

	public String getDeveloper() {
		return developer;
	}

	
	@Value("JAVA")
	public void setDeveloper(String developer) {
		this.developer = developer;
	}

}
