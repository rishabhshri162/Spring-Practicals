package com.rays.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.rays.AppConfig;

public class TestHuman {
	
	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		Human human = context.getBean("human", Human.class);
		
		System.out.println(human.getName());
		System.out.println(human.getAddress());
		System.out.println(human.getme);
	}
}
