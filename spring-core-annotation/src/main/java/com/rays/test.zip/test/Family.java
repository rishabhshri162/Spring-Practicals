package com.rays.test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Family {
	
	private String member;

	public String getMember() {
		return member;
	}
    
	@Value("2")
	public void setMember(String member) {
		this.member = member;
	}
}
